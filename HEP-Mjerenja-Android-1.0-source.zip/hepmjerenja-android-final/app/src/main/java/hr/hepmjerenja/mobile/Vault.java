package hr.hepmjerenja.mobile;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONObject;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Credentials encrypted at rest with a non-exportable Android Keystore key. */
public final class Vault {
    private final Context context;
    private static final String ALIAS="hepmjerenja.credentials.v1";
    public Vault(Context context) { this.context=context; }
    private SecretKey key() throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if(!store.containsAlias(ALIAS)) {
            KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            generator.generateKey();
        }
        return ((KeyStore.SecretKeyEntry)store.getEntry(ALIAS,null)).getSecretKey();
    }
    public boolean exists() { return context.getSharedPreferences("vault",0).contains("cipher"); }
    public void save(String username,String password) throws Exception {
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE,key());
        byte[] data=new JSONObject().put("username",username).put("password",password).toString().getBytes("UTF-8");
        String blob=Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(cipher.doFinal(data),Base64.NO_WRAP);
        if(!context.getSharedPreferences("vault",0).edit().putString("cipher",blob).commit()) throw new Exception("Prijavu nije moguće spremiti.");
    }
    public String[] load() throws Exception {
        String blob=context.getSharedPreferences("vault",0).getString("cipher","");
        String[] parts=blob.split(":");
        if(parts.length!=2) throw new Exception("Potrebna je prijava.");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));
        JSONObject json=new JSONObject(new String(cipher.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),"UTF-8"));
        return new String[]{json.getString("username"),json.getString("password")};
    }
    public void clear() throws Exception {
        context.getSharedPreferences("vault",0).edit().clear().commit();
        KeyStore store=KeyStore.getInstance("AndroidKeyStore"); store.load(null); store.deleteEntry(ALIAS);
    }
}

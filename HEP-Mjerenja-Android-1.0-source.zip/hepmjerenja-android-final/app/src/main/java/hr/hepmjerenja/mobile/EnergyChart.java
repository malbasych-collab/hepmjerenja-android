package hr.hepmjerenja.mobile;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.*;

/** Native Canvas chart. Exact values are also available as accessible text below. */
public final class EnergyChart extends View {
    public interface Select { void selected(String key); }
    private final List<String> keys;
    private final List<Core.Bucket> buckets;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private final Select select;
    private float left,right;
    private static final int GREEN=Color.rgb(0,123,112), ORANGE=Color.rgb(219,139,44);
    public EnergyChart(Context c,Core.Summary summary,Select select) {
        super(c); keys=new ArrayList<>(summary.buckets.keySet()); buckets=new ArrayList<>(summary.buckets.values()); this.select=select;
        d=c.getResources().getDisplayMetrics().density; setMinimumHeight((int)(240*d));
        setContentDescription("Grafikon: zeleno preuzeto iz mreže, narančasto predano u mrežu. Točne vrijednosti navedene su ispod grafikona.");
        setClickable(true);
    }
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas); float bottom=getHeight()-36*d,top=22*d;
        left=48*d; right=getWidth()-12*d;
        long max=1; for(Core.Bucket b:buckets) max=Math.max(max,Math.max(b.in,b.out));
        paint.setTextSize(10*getResources().getDisplayMetrics().scaledDensity);
        for(int i=0;i<5;i++) {
            float y=bottom-(bottom-top)*i/4; paint.setColor(Color.rgb(225,233,230)); paint.setStrokeWidth(d); canvas.drawLine(left,y,right,y,paint);
            paint.setColor(Color.rgb(87,106,99)); paint.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText(String.format(Core.HR,"%.1f",max/(double)Core.UNIT*i/4),left-6*d,y+4*d,paint);
        }
        if(buckets.isEmpty()) return;
        float step=(right-left)/buckets.size(),width=Math.max(1,step*.32f);
        int stride=Math.max(1,(int)Math.ceil(buckets.size()/6.0));
        for(int i=0;i<buckets.size();i++) {
            Core.Bucket b=buckets.get(i); float x=left+step*(i+.5f);
            paint.setColor(GREEN); canvas.drawRect(x-width-1,bottom-(bottom-top)*b.in/max,x-1,bottom,paint);
            paint.setColor(ORANGE); canvas.drawRect(x+1,bottom-(bottom-top)*b.out/max,x+width+1,bottom,paint);
            if(i%stride==0) { paint.setColor(Color.rgb(87,106,99)); paint.setTextAlign(Paint.Align.CENTER); canvas.drawText(b.label,x,bottom+22*d,paint); }
        }
        paint.setTextAlign(Paint.Align.LEFT); paint.setColor(Color.rgb(87,106,99)); canvas.drawText("kWh",left,14*d,paint);
    }
    public boolean onTouchEvent(android.view.MotionEvent event) {
        if(event.getAction()==MotionEvent.ACTION_UP) {
            performClick();
            if(!keys.isEmpty()&&event.getX()>=left&&event.getX()<right) {
                int i=Math.min(keys.size()-1,Math.max(0,(int)((event.getX()-left)/(right-left)*keys.size())));
                select.selected(keys.get(i));
            }
            return true;
        }
        return true;
    }
    public boolean performClick() { super.performClick(); return true; }
}

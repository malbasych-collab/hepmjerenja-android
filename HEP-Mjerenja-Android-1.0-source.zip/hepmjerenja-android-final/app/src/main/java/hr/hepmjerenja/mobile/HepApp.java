package hr.hepmjerenja.mobile;

import android.app.Application;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import java.io.InterruptedIOException;
import java.time.YearMonth;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class HepApp extends Application {
    public Store store;
    public Vault vault;
    public SharedPreferences prefs;
    public final ExecutorService io=Executors.newSingleThreadExecutor();
    public final Handler main=new Handler(Looper.getMainLooper());
    private final Set<Listener> listeners=new HashSet<>();
    public final AtomicBoolean busy=new AtomicBoolean(false);
    private final AtomicBoolean cancel=new AtomicBoolean(false);
    public volatile String message="";
    public volatile boolean failed=false;
    public interface Listener { void changed(); }
    public void onCreate() {
        super.onCreate(); store=new Store(this); vault=new Vault(this); prefs=getSharedPreferences("settings",0);
    }
    public void listen(Listener l) { listeners.add(l); }
    public void unlisten(Listener l) { listeners.remove(l); }
    public void status(String s) {
        message=s; main.post(()->{ for(Listener l:new ArrayList<>(listeners)) l.changed(); });
    }
    public boolean login(String user,String password) {
        if(!busy.compareAndSet(false,true)) return false;
        failed=false; status("Povezivanje s HEP-om…");
        io.execute(()->{
            boolean ok=false;
            try {
                List<Core.Point> points=new HepApi().login(user,password);
                if(points.isEmpty()) throw new Exception("Na računu nema dostupnih mjernih mjesta.");
                vault.save(user,password); store.points(points); ok=true;
                prefs.edit().putString("point",points.get(0).code).apply();
            } catch(Exception e) { failed=true; status(safe(e)); }
            finally { busy.set(false); }
            if(ok) { status("Prijava je uspjela."); sync(true,null,null,null); }
            else status(message);
        });
        return true;
    }
    public void stopSync() { cancel.set(true); status("Zaustavljam nakon tekućeg zahtjeva…"); }
    private void checkCancel() throws InterruptedIOException {
        if(cancel.get()||Thread.currentThread().isInterrupted()) throw new InterruptedIOException("Preuzimanje je zaustavljeno. Spremljeni mjeseci su sačuvani.");
    }
    /** full: missing historical months + refresh latest two; forceMonth can be YYYY-MM or YYYY. */
    public boolean sync(boolean full,String onlyPoint,String forceMonth,Runnable completion) {
        if(!vault.exists()||!busy.compareAndSet(false,true)) return false;
        cancel.set(false); failed=false; status("Provjera dostupnih očitanja…");
        io.execute(()->{
            try {
                String[] credentials=vault.load(); HepApi api=new HepApi();
                List<Core.Point> points=api.login(credentials[0],credentials[1]); checkCancel(); store.points(points);
                YearMonth current=YearMonth.now(Core.ZAGREB);
                List<Task> tasks=new ArrayList<>();
                for(Core.Point p:points) {
                    if(onlyPoint!=null&&!p.code.equals(onlyPoint)) continue;
                    YearMonth end=p.lastMonth(), start=p.firstMonth();
                    if(start.isAfter(end)) continue;
                    if(!full&&forceMonth==null&&start.isBefore(current.minusMonths(1))) start=current.minusMonths(1);
                    for(YearMonth m=end;!m.isBefore(start);m=m.minusMonths(1)) {
                        if(forceMonth!=null&&!m.toString().startsWith(forceMonth)) continue;
                        for(String dir:new String[]{"P","R"}) {
                            if(dir.equals("P")&&!p.consumer || dir.equals("R")&&!p.producer) continue;
                            if(forceMonth!=null||!m.isBefore(current.minusMonths(1))||!store.fetched(p.code,m,dir)) tasks.add(new Task(p,m,dir));
                        }
                    }
                }
                int done=0;
                for(Task task:tasks) {
                    checkCancel();
                    status("Preuzimanje "+(++done)+"/"+tasks.size()+" · "+task.month+" · "+(task.direction.equals("P")?"preuzeto":"predano"));
                    List<Core.Reading> rows;
                    try { rows=api.readings(task.point,task.month,task.direction); }
                    catch(HepApi.ApiException e) {
                        if(!e.auth) throw e;
                        checkCancel(); api.login(credentials[0],credentials[1]);
                        rows=api.readings(task.point,task.month,task.direction);
                    }
                    checkCancel(); store.saveMonth(task.point.code,task.month,task.direction,rows);
                }
                prefs.edit().putLong("lastSuccess",System.currentTimeMillis()).apply();
                status(tasks.isEmpty()?"Nema novih mjeseci za preuzimanje.":"Očitanja su spremljena. Pregled je dostupan i bez interneta.");
            } catch(Exception e) { failed=!cancel.get(); status(cancel.get()?"Preuzimanje zaustavljeno. Spremljeni mjeseci su sačuvani.":safe(e)); }
            finally {
                busy.set(false); status(message);
                if(completion!=null) main.post(completion);
            }
        });
        return true;
    }
    static final class Task {
        Core.Point point; YearMonth month; String direction;
        Task(Core.Point p,YearMonth m,String d) { point=p; month=m; direction=d; }
    }
    public static String safe(Exception e) {
        if(e instanceof java.net.UnknownHostException) return "Nema veze s HEP-om. Provjerite internet. Spremljeni podaci ostaju dostupni.";
        if(e instanceof java.net.SocketTimeoutException) return "HEP nije odgovorio na vrijeme. Pokušajte ponovno.";
        if(e instanceof org.json.JSONException || e instanceof java.time.DateTimeException || e instanceof NumberFormatException)
            return "Format HEP podataka nije prepoznat. Potrebna je provjera ili ažuriranje aplikacije.";
        if(e instanceof java.security.GeneralSecurityException) return "Spremljenu prijavu nije moguće otključati. Ponovno postavite račun.";
        if(e instanceof HepApi.ApiException || e instanceof InterruptedIOException) return e.getMessage();
        return "Radnja nije uspjela. Provjerite vezu i prijavu pa pokušajte ponovno. Postojeći podaci su sačuvani.";
    }
}

package hr.hepmjerenja.mobile;

import org.json.*;
import java.io.*;
import java.net.*;
import java.time.*;
import java.util.*;

/** HEP protocol adapted from edkirin/hepmjerenja. See THIRD_PARTY_NOTICES.md. */
public final class HepApi {
    private static final String BASE="https://mjerenje.hep.hr/mjerenja/v1.1/api";
    private String token="";
    public static class ApiException extends IOException {
        final boolean auth;
        ApiException(String text,boolean auth) { super(text); this.auth=auth; }
    }
    private static class Response { String body; Map<String,List<String>> headers; }
    private Response post(String path,String payload,boolean login) throws Exception {
        if(Thread.currentThread().isInterrupted()) throw new InterruptedIOException("Preuzimanje zaustavljeno.");
        HttpURLConnection c=(HttpURLConnection)new URL(BASE+path).openConnection();
        c.setConnectTimeout(20000); c.setReadTimeout(30000); c.setInstanceFollowRedirects(false);
        c.setRequestMethod("POST"); c.setRequestProperty("Accept","application/json, text/plain, */*");
        c.setRequestProperty("Origin","https://mjerenje.hep.hr");
        c.setRequestProperty("Referer","https://mjerenje.hep.hr/mjerenja/"+(login?"login":"mjerni"));
        if(!login) { c.setRequestProperty("Authorization","Bearer "+token); c.setRequestProperty("Cookie","accessToken="+token); }
        try {
            if(payload!=null) {
                c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=utf-8");
                byte[] bytes=payload.getBytes("UTF-8"); c.setFixedLengthStreamingMode(bytes.length);
                try(OutputStream out=c.getOutputStream()) { out.write(bytes); }
            }
            int status=c.getResponseCode();
            InputStream stream=status>=400?c.getErrorStream():c.getInputStream();
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            if(stream!=null) try(InputStream in=stream) {
                byte[] buffer=new byte[8192]; int n;
                while((n=in.read(buffer))!=-1) {
                    if(Thread.currentThread().isInterrupted()) throw new InterruptedIOException();
                    if(out.size()+n>16*1024*1024) throw new IOException("HEP je poslao prevelik odgovor.");
                    out.write(buffer,0,n);
                }
            }
            String body=out.toString("UTF-8");
            if(status==401 || status==403 || body.contains("Neispravni podaci prijave"))
                throw new ApiException(login?"Prijava nije uspjela. Provjerite korisničko ime i lozinku.":"HEP prijava je istekla.",true);
            if(!login && status==404 && (body.contains("ne sadrži podatke za datum")||body.contains("ne ulazi u dozvoljeni raspon"))) {
                body="[]";
            } else if(status!=200) throw new ApiException("HEP trenutačno ne može obraditi zahtjev (HTTP "+status+").",false);
            Response response=new Response(); response.body=body; response.headers=c.getHeaderFields(); return response;
        } finally { c.disconnect(); }
    }
    public List<Core.Point> login(String username,String password) throws Exception {
        token="";
        Response response=post("/user/login",new JSONObject().put("Username",username).put("Password",password).toString(),true);
        for(Map.Entry<String,List<String>> entry:response.headers.entrySet()) {
            if(entry.getKey()!=null&&entry.getKey().equalsIgnoreCase("Set-Cookie"))
                for(String header:entry.getValue()) for(HttpCookie cookie:HttpCookie.parse(header))
                    if(cookie.getName().equals("accessToken")) token=cookie.getValue();
        }
        if(token.isEmpty()||token.contains("\r")||token.contains("\n")) throw new IOException("HEP nije vratio valjanu potvrdu prijave.");
        JSONArray customers=new JSONArray(response.body);
        LinkedHashMap<String,Core.Point> points=new LinkedHashMap<>();
        for(int i=0;i<customers.length();i++) {
            JSONArray list=customers.getJSONObject(i).optJSONArray("OmmList");
            if(list==null) continue;
            for(int j=0;j<list.length();j++) {
                JSONObject o=list.getJSONObject(j); String code=o.getString("Sifra");
                if(code.isEmpty()) throw new IOException("HEP je vratio praznu šifru mjernog mjesta.");
                points.put(code,new Core.Point(code,o.optString("Adresa",""),o.optString("MjesecOd",""),o.optString("MjesecDo",""),o.optBoolean("Potrosac"),o.optBoolean("Proizvodjac")));
            }
        }
        return new ArrayList<>(points.values());
    }
    public List<Core.Reading> readings(Core.Point point,YearMonth month,String direction) throws Exception {
        String code=URLEncoder.encode(point.code,"UTF-8").replace("+","%20");
        String date=String.format(Locale.ROOT,"%02d.%04d",month.getMonthValue(),month.getYear());
        JSONArray array=new JSONArray(post("/data/omm/"+code+"/krivulja/mjesec/"+date+"/smjer/"+direction,null,false).body);
        List<Core.Reading> rows=new ArrayList<>(); Map<String,Integer> occurrence=new HashMap<>();
        Instant now=Instant.now();
        for(int i=0;i<array.length();i++) {
            JSONObject o=array.getJSONObject(i);
            if(!o.getString("Sifra").equals(point.code)) throw new IOException("HEP je vratio očitanja drugog mjernog mjesta.");
            String raw=o.getString("Datum");
            int index=occurrence.containsKey(raw)?occurrence.get(raw):0; occurrence.put(raw,index+1);
            int allowed=Core.ZAGREB.getRules().getValidOffsets(Core.local(raw)).size();
            if(index>=allowed) throw new IOException("Neočekivano ponovljeno ili nepostojeće vrijeme u HEP podacima.");
            Core.Reading row=new Core.Reading(point.code,direction,raw,index,Core.energy(o.getString("Value")),o.optString("Status",""));
            if(row.start().plusMinutes(15).toInstant().isAfter(now)) continue;
            // HEP pads future slots with zero values. The instant check above removes unfinished
            // intervals while preserving legitimate measured zero values, including today.
            if(!YearMonth.from(row.start()).equals(month)) continue;
            rows.add(row);
        }
        return rows;
    }
}

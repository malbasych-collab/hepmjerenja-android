package hr.hepmjerenja.mobile;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.JsonReader;
import android.util.JsonWriter;
import java.io.*;
import java.util.*;

public final class Transfers {
    private Transfers() {}
    public static void csv(Store store,String point,String prefix,OutputStream stream) throws Exception {
        try(Writer out=new OutputStreamWriter(stream,"UTF-8")) {
            out.write('\ufeff');
            out.write("Mjerno mjesto;Smjer;HEP vrijeme završetka intervala;Redni broj ponovljenog vremena;kWh;HEP status\r\n");
            for(Core.Reading r:store.rows(point,prefix)) {
                out.write(Core.csvCell(r.point)+";"+Core.csvCell(r.direction.equals("P")?"Preuzeto iz mreže":"Predano u mrežu")+";"+Core.csvCell(r.raw)+";"+r.occurrence+";"+
                    java.math.BigDecimal.valueOf(r.value,6).toPlainString().replace('.',',')+";"+Core.csvCell(r.status)+"\r\n");
            }
        }
    }
    public static void backup(Store store,OutputStream stream) throws Exception {
        try(JsonWriter out=new JsonWriter(new OutputStreamWriter(stream,"UTF-8"));
            Cursor c=store.getReadableDatabase().rawQuery("SELECT point,direction,stamp,occurrence,value,status FROM readings ORDER BY point,stamp,occurrence,direction",null)) {
            out.beginObject(); out.name("format").value("HEPMjerenjaAndroid"); out.name("version").value(1);
            out.name("readings").beginArray();
            while(c.moveToNext()) {
                out.beginObject(); out.name("point").value(c.getString(0)); out.name("direction").value(c.getString(1));
                out.name("stamp").value(c.getString(2)); out.name("occurrence").value(c.getInt(3));
                out.name("microKwh").value(c.getLong(4)); out.name("status").value(c.getString(5)); out.endObject();
            }
            out.endArray(); out.endObject();
        }
    }
    public static int restore(Store store,InputStream stream) throws Exception {
        Set<String> known=new HashSet<>(); for(Core.Point p:store.points()) known.add(p.code);
        SQLiteDatabase db=store.getWritableDatabase(); db.beginTransaction(); int count=0;
        try(JsonReader in=new JsonReader(new InputStreamReader(stream,"UTF-8"))) {
            in.setLenient(false); in.beginObject();
            if(!in.nextName().equals("format")||!in.nextString().equals("HEPMjerenjaAndroid")) throw new IOException("Pogrešna datoteka sigurnosne kopije.");
            if(!in.nextName().equals("version")||in.nextInt()!=1) throw new IOException("Nepodržana verzija kopije.");
            if(!in.nextName().equals("readings")) throw new IOException("Nedostaju očitanja.");
            in.beginArray();
            while(in.hasNext()) {
                if(++count>2_000_000) throw new IOException("Sigurnosna kopija sadrži previše očitanja.");
                String point=null,dir=null,stamp=null,status=null; Integer occurrence=null; Long value=null;
                Set<String> fields=new HashSet<>(); in.beginObject();
                while(in.hasNext()) {
                    String name=in.nextName(); if(!fields.add(name)) throw new IOException("Ponovljeno polje u kopiji.");
                    switch(name) {
                        case "point": point=in.nextString(); break;
                        case "direction": dir=in.nextString(); break;
                        case "stamp": stamp=in.nextString(); break;
                        case "occurrence": occurrence=in.nextInt(); break;
                        case "microKwh": value=in.nextLong(); break;
                        case "status": status=in.nextString(); break;
                        default: throw new IOException("Nepoznato polje u kopiji.");
                    }
                }
                in.endObject();
                if(!known.contains(point)||!("P".equals(dir)||"R".equals(dir))||stamp==null||occurrence==null||occurrence<0||value==null||value<0||status==null||status.length()>30)
                    throw new IOException("Neispravna kopija ili mjerno mjesto ne pripada prijavljenom računu.");
                if(occurrence>=Core.ZAGREB.getRules().getValidOffsets(Core.local(stamp)).size()) throw new IOException("Neispravno vrijeme u kopiji.");
                Core.Reading r=new Core.Reading(point,dir,stamp,occurrence,value,status);
                if(r.start().toInstant().isAfter(java.time.Instant.now())) throw new IOException("Kopija sadrži buduća očitanja.");
                ContentValues v=new ContentValues(); v.put("point",point); v.put("direction",dir); v.put("stamp",stamp); v.put("occurrence",occurrence);
                v.put("value",value); v.put("status",status); v.put("day",r.start().toLocalDate().toString()); v.put("month",java.time.YearMonth.from(r.start()).toString());
                // Existing readings are newer/authoritative; restore fills gaps only.
                db.insertWithOnConflict("readings",null,v,SQLiteDatabase.CONFLICT_IGNORE);
            }
            in.endArray(); in.endObject();
            if(in.peek()!=android.util.JsonToken.END_DOCUMENT) throw new IOException("Neočekivan završetak kopije.");
            db.setTransactionSuccessful(); return count;
        } finally { db.endTransaction(); }
    }
}

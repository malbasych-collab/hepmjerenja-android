package hr.hepmjerenja.mobile;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public final class MainActivity extends Activity implements HepApp.Listener {
    private static final int BG=0xFFF4F7F6,INK=0xFF173F36,MUTED=0xFF60776F,GREEN=0xFF007B70,ORANGE=0xFFDB8B2C;
    private static final int CSV=41,BACKUP=42,RESTORE=43;
    private HepApp app;
    private LinearLayout root,body,nav;
    private TextView status;
    private ProgressBar progress;
    private Button refresh;
    private LocalDate date=LocalDate.now(Core.ZAGREB).minusDays(1);
    private int mode=1,renderGeneration=0;
    private boolean shownAccount,wasBusy,started;
    private String point="",pendingPoint="",pendingPrefix="";
    private boolean transferring=false;

    public void onCreate(Bundle state) {
        super.onCreate(state); app=(HepApp)getApplication(); point=app.prefs.getString("point","");
        if(state!=null) {
            date=LocalDate.parse(state.getString("date",date.toString())); mode=state.getInt("mode",1);
            pendingPoint=state.getString("pendingPoint",""); pendingPrefix=state.getString("pendingPrefix","");
        }
        build();
    }
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out); out.putString("date",date.toString()); out.putInt("mode",mode);
        out.putString("pendingPoint",pendingPoint); out.putString("pendingPrefix",pendingPrefix);
    }
    protected void onStart() {
        super.onStart(); started=true; app.listen(this); changed();
        if(app.vault.exists()&&!app.busy.get()&&System.currentTimeMillis()-app.prefs.getLong("lastSuccess",0)>6*60*60*1000L)
            app.sync(true,null,null,null);
    }
    protected void onStop() { started=false; app.unlisten(this); super.onStop(); }
    private int dp(float x) { return (int)(x*getResources().getDisplayMetrics().density+.5f); }
    private TextView text(String s,int size,int color) {
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); v.setPadding(0,dp(4),0,dp(4)); return v;
    }
    private TextView heading(String s,int size) {
        TextView v=text(s,size,INK); v.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL)); return v;
    }
    private LinearLayout column() { LinearLayout v=new LinearLayout(this); v.setOrientation(LinearLayout.VERTICAL); return v; }
    private LinearLayout row() { LinearLayout v=new LinearLayout(this); v.setOrientation(LinearLayout.HORIZONTAL); v.setGravity(Gravity.CENTER_VERTICAL); return v; }
    private GradientDrawable shape(int color,int radius) { GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g; }
    private LinearLayout card(LinearLayout parent) {
        LinearLayout v=column(); v.setPadding(dp(18),dp(14),dp(18),dp(14)); v.setBackground(shape(Color.WHITE,20));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(7),0,dp(7)); parent.addView(v,p); return v;
    }
    private Button button(String label,boolean primary,Runnable action) {
        Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(14); b.setMinHeight(dp(48)); b.setPadding(dp(12),dp(8),dp(12),dp(8));
        b.setTextColor(primary?Color.WHITE:GREEN); b.setBackground(shape(primary?GREEN:0xFFE5F1ED,12)); b.setOnClickListener(v->action.run());
        return b;
    }
    private void addButton(LinearLayout parent,String label,boolean primary,Runnable action) {
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(6),0,dp(6)); parent.addView(button(label,primary,action),p);
    }
    private void build() {
        renderGeneration++; shownAccount=app.vault.exists();
        root=column(); root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom()); return insets;
        });
        setContentView(root); root.requestApplyInsets();
        LinearLayout header=row(); header.setPadding(dp(20),dp(14),dp(20),dp(10));
        LinearLayout titles=column(); titles.addView(text("MOJA ENERGIJA",11,GREEN)); titles.addView(heading("HEP mjerenja",26));
        header.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        if(shownAccount) header.addView(button("Postavke",false,this::settings));
        root.addView(header);
        LinearLayout statusBox=column(); statusBox.setPadding(dp(20),0,dp(20),dp(8));
        status=text(app.message,13,MUTED); status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE); statusBox.addView(status);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setIndeterminate(true); statusBox.addView(progress,new LinearLayout.LayoutParams(-1,dp(3))); root.addView(statusBox);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); body=column(); body.setPadding(dp(16),0,dp(16),dp(24)); scroll.addView(body); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(shownAccount) dashboard(); else login();
        updateStatus();
    }
    private void login() {
        LinearLayout welcome=card(body); welcome.addView(heading("Tvoja očitanja.\nNa tvom mobitelu.",30));
        welcome.addView(text("Preuzimanje izravno s HEP-a. Dnevni, mjesečni i godišnji pregled, dostupan i bez interneta nakon preuzimanja.",16,MUTED));
        LinearLayout form=card(body); form.addView(heading("Poveži HEP račun",21));
        form.addView(text("Unesi iste podatke kao na mjerenje.hep.hr.",14,MUTED));
        EditText user=new EditText(this); user.setSingleLine(true); user.setHint("Korisničko ime / e-mail"); user.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS); user.setAutofillHints(View.AUTOFILL_HINT_USERNAME); form.addView(user);
        EditText pass=new EditText(this); pass.setSingleLine(true); pass.setHint("Lozinka"); pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); pass.setAutofillHints(View.AUTOFILL_HINT_PASSWORD); form.addView(pass);
        addButton(form,"Poveži i preuzmi očitanja",true,()->{
            if(app.busy.get()) return;
            String u=user.getText().toString().trim(),p=pass.getText().toString();
            if(u.isEmpty()) { user.setError("Unesi korisničko ime"); return; }
            if(p.isEmpty()) { pass.setError("Unesi lozinku"); return; }
            app.login(u,p);
        });
        form.addView(text("Lozinka se sprema šifrirano na uređaju i šalje samo HEP-u. Nema vlastitog servera, oglasa ni analitike.",13,MUTED));
        body.addView(text("Neslužbena aplikacija, temeljena na projektu edkirin/hepmjerenja. Nije povezana s HEP-om.",12,MUTED));
    }
    public void changed() {
        if(isFinishing()||isDestroyed()) return;
        if(app.vault.exists()!=shownAccount) { build(); return; }
        boolean finished=wasBusy&&!app.busy.get(); updateStatus();
        if(finished&&shownAccount) dashboard();
    }
    private void updateStatus() {
        wasBusy=app.busy.get();
        status.setText(app.message.isEmpty()?(shownAccount?"Podaci ostaju na ovom uređaju.":"Bez servera · privatna lokalna baza"):app.message);
        status.setTextColor(app.failed?0xFFAA433A:MUTED); progress.setVisibility(wasBusy?View.VISIBLE:View.GONE);
        if(refresh!=null) refresh.setText(wasBusy?"Zaustavi preuzimanje":"Osvježi razdoblje");
    }
    private String prefix() { return mode==2?String.valueOf(date.getYear()):mode==1?YearMonth.from(date).toString():date.toString(); }
    private String title() { return mode==2?String.valueOf(date.getYear()):date.format(DateTimeFormatter.ofPattern(mode==1?"LLLL yyyy.":"d. MMMM yyyy.",Core.HR)); }
    private void dashboard() {
        final int generation=++renderGeneration;
        body.removeAllViews(); List<Core.Point> points=app.store.points();
        if(points.isEmpty()) { body.addView(text("Nema dostupnih mjernih mjesta. Pokušaj osvježiti ili provjeri račun.",17,MUTED)); addButton(body,"Osvježi",true,()->app.sync(true,null,null,null)); return; }
        int selected=0; for(int i=0;i<points.size();i++) if(points.get(i).code.equals(point)) selected=i;
        point=points.get(selected).code; final Core.Point current=points.get(selected);
        Spinner spinner=new Spinner(this); ArrayAdapter<Core.Point> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,points); adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); spinner.setAdapter(adapter); spinner.setSelection(selected);
        spinner.setContentDescription("Odaberi mjerno mjesto"); body.addView(spinner,new LinearLayout.LayoutParams(-1,dp(56)));
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> p) {}
            public void onItemSelected(AdapterView<?> parent,View view,int position,long id) {
                String code=points.get(position).code; if(!code.equals(point)) { point=code; app.prefs.edit().putString("point",point).apply(); dashboard(); }
            }
        });
        LinearLayout modes=row(); String[] names={"Dan","Mjesec","Godina"};
        for(int i=0;i<3;i++) {
            final int m=i; LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(46),1); p.setMargins(dp(3),dp(8),dp(3),dp(8));
            modes.addView(button(names[i],mode==i,()->{ mode=m; dashboard(); }),p);
        }
        body.addView(modes); nav=row();
        nav.addView(button("‹",false,()->move(-1)),new LinearLayout.LayoutParams(dp(48),dp(48)));
        Button period=button(title(),false,this::pickDate); period.setContentDescription("Odaberi razdoblje: "+title()); nav.addView(period,new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(button("›",false,()->move(1)),new LinearLayout.LayoutParams(dp(48),dp(48))); body.addView(nav);
        LinearLayout content=column(); body.addView(content);
        content.addView(text("Učitavanje spremljenog pregleda…",14,MUTED));
        final String chosenPoint=point,chosenPrefix=prefix(); final int chosenMode=mode;
        // Independent local query: do not wait behind an entire historical network sync.
        new Thread(()->{
            try {
                List<Core.Reading> rows=app.store.rows(chosenPoint,chosenPrefix);
                Core.Summary summary=Core.summarize(rows,chosenPrefix,chosenMode);
                long fetched=app.store.lastFetch(chosenPoint,chosenPrefix.length()>7?chosenPrefix.substring(0,7):chosenPrefix);
                app.main.post(()->{ if(generation==renderGeneration&&!isDestroyed()) showSummary(content,summary,rows,current,fetched); });
            } catch(Exception e) {
                app.main.post(()->{ if(generation==renderGeneration&&!isDestroyed()) { content.removeAllViews(); content.addView(text("Spremljeni pregled nije moguće učitati.",15,0xFFAA433A)); } });
            }
        },"local-dashboard").start();
        refresh=button(app.busy.get()?"Zaustavi preuzimanje":"Osvježi razdoblje",true,()->{
            if(transferring) return;
            if(app.busy.get()) app.stopSync(); else app.sync(false,point,mode==2?String.valueOf(date.getYear()):YearMonth.from(date).toString(),null);
        });
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52)); p.setMargins(0,dp(12),0,dp(6)); body.addView(refresh,p);
        body.addView(text("HEP podatke objavljuje naknadno. Pregled nije mjerenje uživo; posljednji dani mogu biti nepotpuni.",12,MUTED));
    }
    private void showSummary(LinearLayout target,Core.Summary s,List<Core.Reading> rows,Core.Point current,long fetched) {
        target.removeAllViews();
        if(s.count==0) {
            LinearLayout empty=card(target); empty.addView(heading("Još nema očitanja",23));
            empty.addView(text("Za ovo razdoblje nema spremljenih podataka. Odaberi drugi datum ili dodirni Osvježi razdoblje.",15,MUTED)); return;
        }
        LinearLayout total=card(target); total.addView(text("PREUZETO IZ MREŽE",12,GREEN)); total.addView(heading(Core.kwh(s.in)+" kWh",34));
        total.addView(text("Predano u mrežu: "+Core.kwh(s.out)+" kWh",17,ORANGE));
        total.addView(text("Neto preuzeto: "+Core.kwh(s.net())+" kWh",15,MUTED));
        if(current.producer) total.addView(text("Predaja u mrežu nije ukupna proizvodnja panela. Potrošnja vlastite solarne energije ovdje nije izmjerena.",12,MUTED));
        boolean twoTariff=!app.prefs.getString("tariff."+point,"Bijeli / crveni").equals("Plavi (jednotarifni)");
        if(twoTariff) {
            LinearLayout tariff=card(target); tariff.addView(heading("Preuzimanje po tarifi",18));
            tariff.addView(text("VT   "+Core.kwh(s.vt)+" kWh     ·     NT   "+Core.kwh(s.nt)+" kWh",16,INK));
            tariff.addView(text("Bijeli/crveni model · hrvatsko ljetno i zimsko vrijeme",12,MUTED));
        }
        LinearLayout chart=card(target); chart.addView(heading(mode==2?"Mjeseci u godini":mode==1?"Dani u mjesecu":"15-minutni intervali",20));
        chart.addView(text("● Preuzeto    ● Predano (narančasto)",12,MUTED));
        chart.addView(new EnergyChart(this,s,key->{
            if(mode==2) { date=YearMonth.parse(key).atDay(1); mode=1; dashboard(); }
            else if(mode==1) { date=LocalDate.parse(key); mode=0; dashboard(); }
        }),new LinearLayout.LayoutParams(-1,dp(240)));
        if(mode!=0) chart.addView(text("Dodirni stupac za detaljniji pregled.",12,MUTED));
        LinearLayout details=card(target); details.addView(heading("Točne vrijednosti",19));
        details.addView(text("Razdoblje      preuzeto / predano · kWh",12,MUTED));
        for(Map.Entry<String,Core.Bucket> e:s.buckets.entrySet()) {
            Core.Bucket b=e.getValue();
            TextView line=text(b.label+"     "+(b.countIn==0?"—":Core.kwh(b.in))+" / "+(b.countOut==0?"—":Core.kwh(b.out)),14,INK);
            details.addView(line);
        }
        String checked=fetched==0?"—":Instant.ofEpochMilli(fetched).atZone(Core.ZAGREB).format(DateTimeFormatter.ofPattern("d. M. yyyy. HH:mm",Core.HR));
        target.addView(text("Zadnji dohvat za razdoblje: "+checked+"\nSpremljeno intervala: "+s.count+(s.flagged>0?" · S HEP oznakom statusa: "+s.flagged:""),12,MUTED));
        target.addView(text("Vrijeme u dnevnom pregledu označava početak intervala. CSV zadržava izvorno HEP vrijeme završetka.",12,MUTED));
    }
    private void move(int amount) {
        LocalDate next=mode==2?date.plusYears(amount):mode==1?date.plusMonths(amount):date.plusDays(amount);
        if(next.isAfter(LocalDate.now(Core.ZAGREB))) next=LocalDate.now(Core.ZAGREB);
        date=next; dashboard();
    }
    private void pickDate() {
        DatePickerDialog dialog=new DatePickerDialog(this,(v,y,m,d)->{ date=LocalDate.of(y,m+1,d); dashboard(); },date.getYear(),date.getMonthValue()-1,date.getDayOfMonth());
        dialog.getDatePicker().setMaxDate(System.currentTimeMillis()); dialog.show();
    }
    private void settings() {
        LinearLayout panel=column(); panel.setPadding(dp(20),dp(8),dp(20),dp(16));
        panel.addView(heading("Podaci i račun",23));
        panel.addView(text("Mjerno mjesto: "+point,13,MUTED));
        panel.addView(text("Tarifni model",14,INK));
        Spinner tariff=new Spinner(this); String[] models={"Bijeli / crveni","Plavi (jednotarifni)"};
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,models); tariff.setAdapter(adapter);
        tariff.setSelection(app.prefs.getString("tariff."+point,models[0]).equals(models[1])?1:0); panel.addView(tariff);
        tariff.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> p) {}
            public void onItemSelected(AdapterView<?> p,View v,int i,long id) { app.prefs.edit().putString("tariff."+point,models[i]).apply(); }
        });
        Switch daily=new Switch(this); daily.setText("Dnevno preuzimanje u pozadini"); daily.setChecked(app.prefs.getBoolean("daily",false)); panel.addView(daily);
        daily.setOnCheckedChangeListener((v,checked)->{
            try { SyncJob.schedule(this,checked); app.prefs.edit().putBoolean("daily",checked).apply(); }
            catch(Exception e) { toast("Android nije prihvatio raspored."); }
        });
        panel.addView(text("Android može odgoditi pozadinsko preuzimanje radi štednje baterije. Pri otvaranju provjeravamo podatke ako zadnji uspješan dohvat nije bio unutar 6 sati.",12,MUTED));
        addButton(panel,"Preuzmi / nastavi cijelu povijest",true,()->{ if(!transferring) app.sync(true,null,null,null); });
        addButton(panel,"Izvezi ovo razdoblje u CSV",false,()->chooseFile(CSV));
        addButton(panel,"Spremi sigurnosnu kopiju",false,()->chooseFile(BACKUP));
        addButton(panel,"Vrati očitanja iz kopije",false,()->chooseFile(RESTORE));
        panel.addView(text("Kopija sadrži očitanja i šifre mjernih mjesta, bez lozinke. Za obnovu se prvo prijavi istim HEP računom. Postojeća očitanja se ne prepisuju.",12,MUTED));
        addButton(panel,"Odjavi i izbriši lokalne podatke",false,this::logout);
        addButton(panel,"O aplikaciji",false,()->new AlertDialog.Builder(this).setTitle("Moja HEP mjerenja 1.0.0").setMessage("Neslužbena nativna Android aplikacija.\n\nHEP protokol prilagođen prema projektu edkirin/hepmjerenja. Licenca izvornog projekta: PolyForm Noncommercial 1.0.0.\n\nhttps://github.com/edkirin/hepmjerenja\nhttps://polyformproject.org/licenses/noncommercial/1.0.0\n\nBez analitike i oglasa. Pristupni podaci šalju se samo na mjerenje.hep.hr. Promjene HEP sučelja mogu zahtijevati novu verziju aplikacije.").setPositiveButton("Zatvori",null).show());
        ScrollView scroll=new ScrollView(this); scroll.addView(panel);
        AlertDialog dialog=new AlertDialog.Builder(this).setView(scroll).setPositiveButton("Gotovo",(d,w)->dashboard()).create(); dialog.show();
    }
    private void chooseFile(int type) {
        if(app.busy.get()||transferring) { toast("Najprije pričekaj ili zaustavi preuzimanje."); return; }
        pendingPoint=point; pendingPrefix=prefix();
        Intent intent=new Intent(type==RESTORE?Intent.ACTION_OPEN_DOCUMENT:Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType(type==CSV?"text/csv":"application/json");
        if(type!=RESTORE) intent.putExtra(Intent.EXTRA_TITLE,type==CSV?"HEP-"+pendingPrefix+".csv":"HEP-sigurnosna-kopija-"+LocalDate.now()+".json");
        try { startActivityForResult(intent,type); } catch(ActivityNotFoundException e) { toast("Nije dostupan odabir datoteke."); }
    }
    protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null) return;
        if(request!=CSV&&request!=BACKUP&&request!=RESTORE) return;
        Uri uri=data.getData();
        if(request==RESTORE) new AlertDialog.Builder(this).setTitle("Vrati očitanja?").setMessage("Uvest će se očitanja samo za mjerno mjesto dostupno prijavljenom računu. Postojeća očitanja imaju prednost.").setNegativeButton("Odustani",null).setPositiveButton("Vrati",(d,w)->transfer(request,uri)).show();
        else transfer(request,uri);
    }
    private void transfer(int request,Uri uri) {
        if(!app.busy.compareAndSet(false,true)) { toast("Preuzimanje je u tijeku. Pokušaj ponovno nakon završetka."); return; }
        transferring=true; app.failed=false; app.status("Obrada datoteke…");
        final String exportPoint=pendingPoint,exportPrefix=pendingPrefix;
        app.io.execute(()->{
            try {
                if(request==RESTORE) {
                    try(InputStream in=getContentResolver().openInputStream(uri)) {
                        if(in==null) throw new IOException();
                        Transfers.restore(app.store,in);
                    }
                } else try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")) {
                    if(out==null) throw new IOException();
                    if(request==CSV) Transfers.csv(app.store,exportPoint,exportPrefix,out); else Transfers.backup(app.store,out);
                }
                app.status(request==RESTORE?"Očitanja iz kopije su obrađena.":"Datoteka je spremljena.");
            } catch(Exception e) { app.failed=true; app.status("Datoteku nije moguće obraditi. Provjeri format, račun i dostupni prostor. Baza je sačuvana."); }
            finally { transferring=false; app.busy.set(false); app.status(app.message); }
        });
    }
    private void logout() {
        if(app.busy.get()) { toast("Najprije pričekaj ili zaustavi preuzimanje."); return; }
        new AlertDialog.Builder(this).setTitle("Izbrisati podatke s mobitela?").setMessage("Izbrisat će se spremljena prijava i sva lokalna očitanja. HEP račun ostaje nepromijenjen. Ako trebaš lokalnu povijest, prvo spremi kopiju.")
            .setNegativeButton("Odustani",null).setPositiveButton("Izbriši",(dialog,which)->{
                if(!app.busy.compareAndSet(false,true)) return;
                app.io.execute(()->{
                    try { SyncJob.schedule(this,false); app.store.clear(); app.vault.clear(); app.prefs.edit().clear().commit(); app.failed=false; app.message=""; }
                    catch(Exception e) { app.failed=true; app.message="Brisanje nije potpuno uspjelo. Pokušaj ponovno."; }
                    finally { app.busy.set(false); app.status(app.message); }
                });
            }).show();
    }
    private void toast(String message) { Toast.makeText(this,message,Toast.LENGTH_LONG).show(); }
}

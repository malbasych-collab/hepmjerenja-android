package hr.hepmjerenja.mobile;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Pure JVM domain layer; energy stored as integer micro-kWh, never binary floats. */
public final class Core {
    public static final ZoneId ZAGREB = ZoneId.of("Europe/Zagreb");
    public static final Locale HR = new Locale("hr", "HR");
    public static final long UNIT = 1_000_000L;
    private Core() {}

    public static long energy(String value) {
        BigDecimal n = new BigDecimal(value.trim().replace(',', '.'));
        if (n.signum() < 0) throw new IllegalArgumentException("Negativno očitanje");
        return n.movePointRight(6).setScale(0, RoundingMode.HALF_UP).longValueExact();
    }
    public static String kwh(long value) {
        return String.format(HR, "%,2.2f", value / (double) UNIT);
    }
    public static LocalDateTime local(String raw) {
        return LocalDateTime.parse(raw, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    }
    /** HEP profile timestamps represent the END of a 15 minute interval. */
    public static ZonedDateTime intervalStart(String raw, int occurrence) {
        LocalDateTime end = local(raw);
        List<ZoneOffset> offsets = ZAGREB.getRules().getValidOffsets(end);
        if (offsets.isEmpty()) throw new IllegalArgumentException("Nepostojeće lokalno vrijeme");
        ZoneOffset offset = offsets.get(Math.min(occurrence, offsets.size() - 1));
        return ZonedDateTime.ofLocal(end, ZAGREB, offset).minusMinutes(15);
    }
    public static boolean highTariff(ZonedDateTime start) {
        boolean summer = !ZAGREB.getRules().getDaylightSavings(start.toInstant()).isZero();
        int hour = start.withZoneSameInstant(ZAGREB).getHour();
        return hour >= (summer ? 8 : 7) && hour < (summer ? 22 : 21);
    }
    public static final class Point {
        public String code, address, from, to;
        public boolean consumer, producer;
        public Point(String code, String address, String from, String to, boolean consumer, boolean producer) {
            this.code=code; this.address=address; this.from=from; this.to=to;
            this.consumer=consumer; this.producer=producer;
        }
        public YearMonth firstMonth() {
            try { return YearMonth.parse(from.substring(0,7)); }
            catch (Exception e) { return YearMonth.now(ZAGREB); }
        }
        public YearMonth lastMonth() {
            YearMonth now=YearMonth.now(ZAGREB);
            try { YearMonth end=YearMonth.parse(to.substring(0,7)); return end.isBefore(now)?end:now; }
            catch (Exception e) { return now; }
        }
        public String toString() { return (address.isEmpty()?"Mjerno mjesto":address)+" · "+code; }
    }
    public static final class Reading {
        public String point, direction, raw, status;
        public int occurrence;
        public long value;
        public Reading(String point, String direction, String raw, int occurrence, long value, String status) {
            this.point=point; this.direction=direction; this.raw=raw; this.occurrence=occurrence; this.value=value; this.status=status;
        }
        public ZonedDateTime start() { return intervalStart(raw, occurrence); }
    }
    public static final class Bucket {
        public String label;
        public long in, out;
        public int countIn, countOut;
        public Bucket(String label) { this.label=label; }
    }
    public static final class Summary {
        public long in, out, vt, nt;
        public int count, flagged;
        public final TreeMap<String,Bucket> buckets=new TreeMap<>();
        public long net() { return in-out; }
    }
    public static Summary summarize(List<Reading> readings, String prefix, int mode) {
        Summary s=new Summary();
        for (Reading r:readings) {
            ZonedDateTime start=r.start();
            String date=start.toLocalDate().toString();
            if (!date.startsWith(prefix)) continue;
            String key=mode==2?date.substring(0,7):mode==0?start.toLocalDateTime().toString()+start.getOffset():date;
            String label=mode==2?String.valueOf(start.getMonthValue()):mode==0?start.toLocalTime().toString():String.valueOf(start.getDayOfMonth());
            Bucket b=s.buckets.get(key);
            if (b==null) { b=new Bucket(label); s.buckets.put(key,b); }
            if (r.direction.equals("P")) {
                s.in+=r.value; b.in+=r.value; b.countIn++;
                if(highTariff(start)) s.vt+=r.value; else s.nt+=r.value;
            } else { s.out+=r.value; b.out+=r.value; b.countOut++; }
            s.count++;
            if(!r.status.equals("0")&&!r.status.isEmpty()) s.flagged++;
        }
        return s;
    }
    public static String csvCell(String value) {
        // Spreadsheet applications may evaluate formula-looking text, even in quoted CSV cells.
        if (value.matches("^[=+@\\-].*")) value="'"+value;
        return "\""+value.replace("\"", "\"\"")+"\"";
    }
}

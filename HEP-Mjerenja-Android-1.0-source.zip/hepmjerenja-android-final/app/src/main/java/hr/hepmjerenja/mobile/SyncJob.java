package hr.hepmjerenja.mobile;

import android.app.job.*;
import android.content.*;
import java.util.concurrent.TimeUnit;

/** Opt-in daily, inexact sync using Android's platform scheduler. */
public final class SyncJob extends JobService {
    private static final int ID=4318;
    private boolean ownsSync;
    public static void schedule(Context c,boolean enabled) {
        JobScheduler jobs=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if(!enabled) { jobs.cancel(ID); return; }
        int result=jobs.schedule(new JobInfo.Builder(ID,new ComponentName(c,SyncJob.class))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true)
            .setPeriodic(TimeUnit.HOURS.toMillis(24),TimeUnit.HOURS.toMillis(4))
            .setRequiresBatteryNotLow(true).build());
        if(result!=JobScheduler.RESULT_SUCCESS) throw new IllegalStateException("Raspored nije spremljen.");
    }
    public boolean onStartJob(JobParameters p) {
        HepApp app=(HepApp)getApplication();
        ownsSync=app.sync(false,null,null,()->{ ownsSync=false; jobFinished(p,app.failed); });
        return ownsSync;
    }
    public boolean onStopJob(JobParameters p) {
        if(ownsSync) ((HepApp)getApplication()).stopSync();
        ownsSync=false;
        return true;
    }
}

package hr.hepmjerenja.mobile;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.time.YearMonth;
import java.util.*;

public final class Store extends SQLiteOpenHelper {
    public Store(Context c) { this(c,"readings.db"); }
    Store(Context c,String filename) { super(c,filename,null,1); setWriteAheadLoggingEnabled(true); }
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE points(code TEXT PRIMARY KEY,address TEXT NOT NULL,first TEXT,last TEXT,consumer INTEGER,producer INTEGER)");
        db.execSQL("CREATE TABLE readings(point TEXT NOT NULL,direction TEXT NOT NULL,stamp TEXT NOT NULL,occurrence INTEGER NOT NULL,value INTEGER NOT NULL,status TEXT NOT NULL,day TEXT NOT NULL,month TEXT NOT NULL,PRIMARY KEY(point,direction,stamp,occurrence))");
        db.execSQL("CREATE INDEX readings_period ON readings(point,day)");
        db.execSQL("CREATE TABLE fetched(point TEXT NOT NULL,month TEXT NOT NULL,direction TEXT NOT NULL,at INTEGER NOT NULL,PRIMARY KEY(point,month,direction))");
    }
    public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) { throw new IllegalStateException("Nedostaje migracija baze."); }
    public void points(List<Core.Point> points) {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try {
            // A successful login is authoritative for the accessible meter list.
            db.delete("points",null,null);
            for(Core.Point p:points) {
                ContentValues v=new ContentValues(); v.put("code",p.code); v.put("address",p.address); v.put("first",p.from); v.put("last",p.to);
                v.put("consumer",p.consumer?1:0); v.put("producer",p.producer?1:0);
                db.insertOrThrow("points",null,v);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }
    public List<Core.Point> points() {
        List<Core.Point> points=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT code,address,first,last,consumer,producer FROM points ORDER BY address,code",null)) {
            while(c.moveToNext()) points.add(new Core.Point(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4)!=0,c.getInt(5)!=0));
        }
        return points;
    }
    public boolean fetched(String point,YearMonth month,String direction) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM fetched WHERE point=? AND month=? AND direction=?",new String[]{point,month.toString(),direction})) { return c.moveToFirst(); }
    }
    public void saveMonth(String point,YearMonth month,String direction,List<Core.Reading> rows) {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try {
            // Replace only after the entire response has validated; network failure never wipes data.
            // An empty response must not erase an older local archive.
            if(!rows.isEmpty()) db.delete("readings","point=? AND month=? AND direction=?",new String[]{point,month.toString(),direction});
            for(Core.Reading r:rows) {
                ContentValues v=new ContentValues(); v.put("point",point); v.put("direction",direction); v.put("stamp",r.raw); v.put("occurrence",r.occurrence);
                v.put("value",r.value); v.put("status",r.status); v.put("day",r.start().toLocalDate().toString()); v.put("month",month.toString());
                db.insertOrThrow("readings",null,v);
            }
            ContentValues v=new ContentValues(); v.put("point",point); v.put("month",month.toString()); v.put("direction",direction); v.put("at",System.currentTimeMillis());
            db.insertWithOnConflict("fetched",null,v,SQLiteDatabase.CONFLICT_REPLACE);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }
    public List<Core.Reading> rows(String point,String prefix) {
        ArrayList<Core.Reading> rows=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT point,direction,stamp,occurrence,value,status FROM readings WHERE point=? AND day LIKE ? ORDER BY stamp,occurrence,direction",new String[]{point,prefix+"%"})) {
            while(c.moveToNext()) rows.add(new Core.Reading(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getLong(4),c.getString(5)));
        }
        return rows;
    }
    public long lastFetch(String point,String monthPrefix) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT MAX(at) FROM fetched WHERE point=? AND month LIKE ?",new String[]{point,monthPrefix+"%"})) { return c.moveToFirst()?c.getLong(0):0; }
    }
    public String latestDay(String point) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT MAX(day) FROM readings WHERE point=?",new String[]{point})) { return c.moveToFirst()?c.getString(0):null; }
    }
    public void clear() {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { db.delete("readings",null,null); db.delete("fetched",null,null); db.delete("points",null,null); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); }
    }
}

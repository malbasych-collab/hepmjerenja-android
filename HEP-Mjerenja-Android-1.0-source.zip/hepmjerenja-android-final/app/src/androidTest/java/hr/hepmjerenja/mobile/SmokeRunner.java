package hr.hepmjerenja.mobile;

import android.app.*;
import android.content.*;
import android.os.Bundle;
import java.io.*;
import java.time.YearMonth;
import java.util.*;

/** SDK-only instrumentation: isolated persistence, backup rollback and real native launch. */
public final class SmokeRunner extends Instrumentation {
    public void onCreate(Bundle arguments) { super.onCreate(arguments); start(); }
    public void onStart() {
        Bundle result=new Bundle(); Store a=null,b=null;
        Bundle testStatus=new Bundle(); testStatus.putString("class",getClass().getName()); testStatus.putString("test","nativeSmoke"); testStatus.putInt("numtests",1); testStatus.putInt("current",1); sendStatus(1,testStatus);
        try {
            Context context=getTargetContext();
            context.deleteDatabase("test-source.db"); context.deleteDatabase("test-restore.db");
            a=new Store(context,"test-source.db"); b=new Store(context,"test-restore.db");
            Core.Point point=new Core.Point("test-123","Test","2026-01-01T00:00:00","2026-02-01T00:00:00",true,true);
            a.points(Arrays.asList(point)); b.points(Arrays.asList(point));
            Core.Reading r=new Core.Reading("test-123","P","2026-01-01T00:15:00",0,596000L,"0");
            a.saveMonth(point.code,YearMonth.of(2026,1),"P",Arrays.asList(r));
            a.saveMonth(point.code,YearMonth.of(2026,1),"P",Arrays.asList(r));
            check(a.rows(point.code,"2026-01").size()==1,"idempotent refresh");
            a.saveMonth(point.code,YearMonth.of(2026,1),"P",Collections.emptyList());
            check(a.rows(point.code,"2026-01").size()==1,"empty response preserves archive");
            ByteArrayOutputStream out=new ByteArrayOutputStream(); Transfers.backup(a,out);
            Transfers.restore(b,new ByteArrayInputStream(out.toByteArray()));
            check(b.rows(point.code,"2026-01").get(0).value==596000L,"backup round trip");
            r.value=700000L; b.saveMonth(point.code,YearMonth.of(2026,1),"P",Arrays.asList(r));
            Transfers.restore(b,new ByteArrayInputStream(out.toByteArray()));
            check(b.rows(point.code,"2026-01").get(0).value==700000L,"restore does not overwrite newer values");
            String invalid=new String(out.toByteArray(),"UTF-8").replace("test-123","foreign");
            boolean rejected=false; try { Transfers.restore(b,new ByteArrayInputStream(invalid.getBytes("UTF-8"))); } catch(Exception expected) { rejected=true; }
            check(rejected,"foreign meter rejected"); check(b.rows(point.code,"2026-01").size()==1,"restore rollback");
            ByteArrayOutputStream csv=new ByteArrayOutputStream(); Transfers.csv(a,point.code,"2026",csv);
            check(csv.toString("UTF-8").contains("0,596000"),"CSV decimal precision");
            if(!new Vault(context).exists()) {
                Intent intent=new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                Activity activity=startActivitySync(intent); waitForIdleSync();
                runOnMainSync(()->{ check(activity.findViewById(android.R.id.content)!=null,"native UI launch"); activity.finish(); });
            }
            result.putString("stream","PASS: native launch, SQLite idempotency, zero-response preservation, backup round trip, conflict handling, rollback, CSV\n");
            sendStatus(0,testStatus); finish(Activity.RESULT_OK,result);
        } catch(Throwable error) {
            result.putString("stream","FAIL: "+error.toString()+"\n"); testStatus.putString("stack",error.toString()); sendStatus(-2,testStatus); finish(Activity.RESULT_CANCELED,result);
        } finally {
            if(a!=null) a.close(); if(b!=null) b.close();
            getTargetContext().deleteDatabase("test-source.db"); getTargetContext().deleteDatabase("test-restore.db");
        }
    }
    private static void check(boolean condition,String label) { if(!condition) throw new AssertionError(label); }
}

package hr.hepmjerenja.mobile;
import java.time.*;
import java.util.*;
public final class CoreTest {
    static int checks=0;
    static void eq(Object actual,Object expected,String name) {
        checks++; if(!actual.equals(expected)) throw new AssertionError(name+": "+actual+" != "+expected);
    }
    static void invalid(Runnable code,String name) {
        checks++; try { code.run(); } catch(RuntimeException expected) { return; }
        throw new AssertionError("Expected rejection: "+name);
    }
    static Core.Reading r(String stamp,long value,String dir) { return new Core.Reading("123",""+dir,stamp,0,value,"0"); }
    public static void main(String[] args) {
        eq(Core.energy("0,59600000"),596000L,"HEP decimal comma");
        eq(Core.energy(" 12.345678 "),12345678L,"decimal dot");
        eq(Core.energy("0"),0L,"zero preserved");
        eq(Core.energy("0,0000005"),1L,"micro-kWh rounding");
        invalid(()->Core.energy("NaN"),"NaN"); invalid(()->Core.energy("-1"),"negative energy");
        invalid(()->Core.energy("1e99"),"overflow");
        eq(Core.intervalStart("2026-09-01T00:00:00",0).toLocalDate(),LocalDate.of(2026,8,31),"midnight assigned to previous day");
        eq(Core.intervalStart("2026-09-01T00:15:00",0).toLocalTime(),LocalTime.MIDNIGHT,"first interval");
        eq(Core.highTariff(Core.intervalStart("2026-01-05T07:00:00",0)),false,"winter last NT");
        eq(Core.highTariff(Core.intervalStart("2026-01-05T07:15:00",0)),true,"winter first VT");
        eq(Core.highTariff(Core.intervalStart("2026-01-05T21:00:00",0)),true,"winter last VT");
        eq(Core.highTariff(Core.intervalStart("2026-01-05T21:15:00",0)),false,"winter first NT");
        eq(Core.highTariff(Core.intervalStart("2026-07-05T08:00:00",0)),false,"summer last NT");
        eq(Core.highTariff(Core.intervalStart("2026-07-05T08:15:00",0)),true,"summer first VT");
        eq(Core.highTariff(Core.intervalStart("2026-07-05T22:00:00",0)),true,"summer last VT");
        eq(Core.highTariff(Core.intervalStart("2026-07-05T22:15:00",0)),false,"summer first NT");
        ZonedDateTime first=Core.intervalStart("2026-10-25T02:30:00",0),second=Core.intervalStart("2026-10-25T02:30:00",1);
        eq(Duration.between(first,second).getSeconds(),3600L,"autumn repeated interval retained");
        eq(Core.intervalStart("2026-03-29T03:00:00",0).toLocalTime(),LocalTime.of(1,45),"spring interval crosses missing hour");
        invalid(()->Core.intervalStart("2026-03-29T02:30:00",0),"nonexistent spring time");
        List<Core.Reading> rows=Arrays.asList(r("2026-09-01T00:00:00",9000000,"P"),r("2026-09-01T00:15:00",2000000,"P"),r("2026-09-01T08:15:00",3000000,"P"),r("2026-09-01T08:15:00",1000000,"R"));
        Core.Summary summary=Core.summarize(rows,"2026-09",1);
        eq(summary.in,5000000L,"monthly import excludes previous midnight"); eq(summary.out,1000000L,"monthly export");
        eq(summary.net(),4000000L,"net import"); eq(summary.vt,3000000L,"VT only import"); eq(summary.nt,2000000L,"NT only import");
        eq(summary.buckets.size(),1,"daily bucket");
        eq(Core.summarize(rows,"2026",2).buckets.size(),2,"yearly month boundary");
        Core.Reading zero=r("2026-09-01T01:00:00",0,"P"); zero.status="2";
        Core.Summary z=Core.summarize(Arrays.asList(zero),"2026-09",1);
        eq(z.count,1,"zero is data"); eq(z.flagged,1,"nonzero HEP status reported");
        eq(Core.csvCell("=SUM(A1)"),"\"'=SUM(A1)\"","CSV formula guard");
        eq(Core.csvCell("A\"B"),"\"A\"\"B\"","CSV escaping");
        eq(Core.kwh(1500000L),"1,50","Croatian display");
        System.out.println("PASS: "+checks+" domain assertions");
    }
}

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/core-tests
java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -d build/core-tests app/src/main/java/hr/hepmjerenja/mobile/Core.java tests/CoreTest.java
java -cp build/core-tests hr.hepmjerenja.mobile.CoreTest

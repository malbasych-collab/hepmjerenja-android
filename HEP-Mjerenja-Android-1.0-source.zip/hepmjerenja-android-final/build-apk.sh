#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v gradle >/dev/null; then
  echo 'Potreban je Gradle 8.11.1 na PATH-u (ili otvorite projekt u Android Studiju).'
  exit 1
fi
bash tests/run.sh
gradle --no-daemon :app:assembleDebug :app:lintDebug
printf '\nAPK: %s/app/build/outputs/apk/debug/app-debug.apk\n' "$PWD"

# Moja HEP mjerenja — nativni Android 1.0

Nativna Android aplikacija na hrvatskom, bez WebViewa i bez vlastitog servera. Aplikacija se izravno spaja na `mjerenje.hep.hr`, sprema očitanja lokalno i nakon prvog dohvaćanja omogućuje pregled bez interneta.

## Što je ugrađeno

- izravna HTTPS prijava na HEP mjerenja i automatska obnova poništene sesije
- HEP korisničko ime i lozinka zaštićeni AES-GCM enkripcijom s neizvozivim Android Keystore ključem
- sva mjerna mjesta dostupna prijavljenom HEP računu
- preuzimanje dostupne povijesti mjesec po mjesec, uz mogućnost zaustavljanja i nastavka
- ručno osvježavanje odabranog dana/mjeseca/godine
- lokalna SQLite baza; mrežni neuspjeh ne briše već spremljene podatke
- dnevni 15-minutni pregled, dnevni graf po mjesecu i mjesečni graf po godini
- dodir stupca za prelazak na detaljnije razdoblje
- preuzeto iz mreže, predano u mrežu i neto preuzimanje
- VT/NT za bijeli/crveni tarifni model te jednotarifni prikaz za plavi model
- prikaz točnih vrijednosti ispod grafikona
- automatska provjera pri otvaranju ako uspješan dohvat nije bio unutar 6 sati
- neobavezno dnevno pozadinsko osvježavanje preko Android JobSchedulera
- CSV izvoz razdoblja
- JSON sigurnosna kopija očitanja i obnova bez prepisivanja novijih postojećih podataka
- lokalna prijava i podaci bez analitike, oglasa i posredničkog servera

Predaja energije u mrežu nije isto što i ukupna proizvodnja solarne elektrane: HEP brojilo ne prikazuje izravno energiju koju kuća odmah sama potroši iz panela.

## Podržani Android

- minimalno Android 8.0 (API 26)
- target SDK 35
- Java 8 / Android Views / Canvas
- bez aplikacijskih biblioteka trećih strana

## Izgradnja APK-a

Projekt sadrži GitHub Actions workflow `.github/workflows/android.yml`. Nakon što se sadržaj projekta nalazi u GitHub repozitoriju, push na `main`/`master` ili ručni **Run workflow** instalira SDK 35, pokreće računske testove i lint te izrađuje artifact:

`HEP-Mjerenja-Android-1.0.0/HEP-Mjerenja-1.0.0.apk`

Lokalno je potreban JDK 17, Android SDK 35 i Gradle 8.11.1:

```bash
bash tests/run.sh
gradle --no-daemon :app:assembleDebug :app:lintDebug
```

## Prva provjera na telefonu

Nakon instalacije prijavu upišite samo u aplikaciju. Prvi dohvat cijele povijesti može potrajati. Za početak usporedite jedan završeni mjesec i jedan dan s HEP portalom, uključujući prijelaz oko ponoći, a zatim provjerite CSV i sigurnosnu kopiju.

HEP API koji aplikacija koristi nije javno dokumentiran i može se promijeniti. Ovo nije službena HEP aplikacija.

## Licenca / izvor protokola

HEP protokol prilagođen je prema projektu `edkirin/hepmjerenja`, koji koristi **PolyForm Noncommercial License 1.0.0**. Vidi `THIRD_PARTY_NOTICES.md`. Ova izvedba namijenjena je osobnoj nekomercijalnoj uporabi.

# Podrijetlo i licenca

HEP protokol (putanje, tijela zahtjeva, session cookie i struktura odgovora) prilagođen je prema projektu:

- HEPMjerenja, autor edkirin: https://github.com/edkirin/hepmjerenja
- Izvorni klijent: https://github.com/edkirin/hepmjerenja/blob/main/app/hep_client.go
- Modeli: https://github.com/edkirin/hepmjerenja/blob/main/app/models.go
- Izvorna licenca: PolyForm Noncommercial License 1.0.0
- Puni uvjeti: https://polyformproject.org/licenses/noncommercial/1.0.0
- Licenca u repozitoriju: https://github.com/edkirin/hepmjerenja/blob/main/LICENSE

Ova prilagodba namijenjena je osobnoj, nekomercijalnoj uporabi i isporučuje se pod istim uvjetima PolyForm Noncommercial 1.0.0. Pri daljnjoj distribuciji zadržite ovu obavijest i poveznicu na pune uvjete.

Android sučelje, lokalna baza, zaštita prijave, izvoz/uvoz i raspoređivanje napisani su za ovaj projekt. Nije preuzet izvorni web frontend. Aplikacija nije povezana s HEP-om niti s autorom izvornog projekta. Ne uključuje Google Play Services, analitiku ili oglase.

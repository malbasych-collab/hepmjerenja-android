# Provjera isporuke — 7. rujna 2026.

| Provjera | Rezultat |
|---|---|
| Računski testovi `tests/run.sh` | PROŠLO — 32 asercije |
| Java sintaksa produkcijskih i instrumentacijskih izvora | PROŠLA |
| XML manifest, stil i vektorska ikona | PROŠLI XML parser |
| SQLite DDL sintaksa | PROŠLA u prethodnoj provjeri projekta |
| Android kompilacija + lint | Čeka GitHub Actions / Android SDK build okruženje |
| Stvarna HEP prijava | Nije izvođena bez korisničkih vjerodajnica |
| Fizički Android 16 test | Čeka prvi instalacijski APK |

Ne upisivati HEP vjerodajnice u izvorni kod, GitHub Actions ili chat. Unose se samo u instaliranu aplikaciju.

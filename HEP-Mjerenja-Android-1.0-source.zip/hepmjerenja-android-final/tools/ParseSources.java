import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;
/** Syntax-only validation: deliberately does not claim Android type checking. */
class ParseSources {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
        try(StandardJavaFileManager fm=compiler.getStandardFileManager(diagnostics,null,null)) {
            List<File> files;
            try(Stream<Path> paths=Files.walk(Paths.get(args[0]))) {
                files=paths.filter(p->p.toString().endsWith(".java")).map(Path::toFile).collect(Collectors.toList());
            }
            JavacTask task=(JavacTask)compiler.getTask(null,fm,diagnostics,Arrays.asList("-proc:none","-encoding","UTF-8"),null,fm.getJavaFileObjectsFromFiles(files));
            task.parse();
            for(Diagnostic<?> d:diagnostics.getDiagnostics()) if(d.getKind()==Diagnostic.Kind.ERROR) throw new IllegalStateException(d.toString());
            System.out.println("PASS: Java syntax parsed for "+files.size()+" source files (Android types not checked)");
        }
    }
}
